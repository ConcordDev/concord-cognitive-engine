def greet():
    return "hello from a real vendored local wheel"
